create function st_pixelaspolygon(rast raster, x integer, y integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT geom FROM _st_pixelaspolygons($1, NULL, $2, $3)
$$;

comment on function st_pixelaspolygon(raster, integer, integer) is 'args: rast, columnx, rowy - Returns the polygon geometry that bounds the pixel for a particular row and column.';

alter function st_pixelaspolygon(raster, integer, integer) owner to rosia;


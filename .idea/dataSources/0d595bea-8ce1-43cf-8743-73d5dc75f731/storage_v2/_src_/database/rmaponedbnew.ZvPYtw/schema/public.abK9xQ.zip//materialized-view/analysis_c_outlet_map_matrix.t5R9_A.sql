create materialized view analysis_c_outlet_map_matrix as
WITH percentilepivot AS (
    SELECT count(DISTINCT ocpm_1.outlet_id) AS total_outlets
    FROM analysis_b_outlet_class_point_map ocpm_1
)
SELECT ocpm.outlet_id,
       ocpm.customer_class_id,
       ocpm.class_title,
       ocpm.points,
       ocpm.percentage,
       ocpm.template_id,
       1::double precision -
       (ocpm.rank / ocpm.customer_class_id)::double precision / ((SELECT percentilepivot.total_outlets
                                                                  FROM percentilepivot))::double precision AS percentile
FROM analysis_b_outlet_class_point_map ocpm;

alter materialized view analysis_c_outlet_map_matrix owner to rosia;


create materialized view analysis_b_outlet_class_point_map as
SELECT outlet_ranks.outlet_id,
       outlet_ranks.customer_class_id,
       outlet_ranks.class_title,
       outlet_ranks.points,
       outlet_ranks.percentage,
       outlet_ranks.template_id,
       row_number() OVER () AS rank
FROM (WITH percentilepivot AS (
    SELECT aocsm_1.outlet_id,
           count(aocsm_1.sku) AS percentageref
    FROM analysis_a_outlet_class_sku_map aocsm_1
    GROUP BY aocsm_1.outlet_id
)
      SELECT outlet_class.outlet_id,
             outlet_class.customer_class_id,
             outlet_class.class_title,
             count(aocsm.sku)              AS points,
             outlet_class.template_id,
             COALESCE(count(aocsm.sku)::double precision / NULLIF(percentilepivot.percentageref, 0)::double precision,
                      0::double precision) AS percentage
      FROM (SELECT ro.id                    AS outlet_id,
                   acc.id                   AS customer_class_id,
                   acc.customer_class_title AS class_title,
                   acc.template_id
            FROM analysis_customer_class acc,
                 retail_outlet ro) outlet_class
               LEFT JOIN percentilepivot ON percentilepivot.outlet_id = outlet_class.outlet_id
               LEFT JOIN analysis_a_outlet_class_sku_map aocsm
                         ON aocsm.customer_class_id = outlet_class.customer_class_id AND
                            aocsm.outlet_id = outlet_class.outlet_id
      GROUP BY outlet_class.outlet_id, outlet_class.customer_class_id, outlet_class.class_title,
               percentilepivot.percentageref, outlet_class.template_id
      ORDER BY outlet_class.template_id, outlet_class.customer_class_id, (count(aocsm.sku)) DESC,
               outlet_class.outlet_id) outlet_ranks;

alter materialized view analysis_b_outlet_class_point_map owner to rosia;


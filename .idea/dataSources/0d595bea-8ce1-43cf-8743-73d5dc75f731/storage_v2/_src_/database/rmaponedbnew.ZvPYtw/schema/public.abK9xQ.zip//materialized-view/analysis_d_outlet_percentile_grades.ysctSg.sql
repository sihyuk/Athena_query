create materialized view analysis_d_outlet_percentile_grades as
SELECT os.outlet_id,
       os.customer_class_id,
       os.class_title,
       os.template_id,
       max(rg.grade) AS grade
FROM analysis_c_outlet_map_matrix os
         JOIN analysis_grading rg ON rg.customer_class_id = os.customer_class_id
WHERE os.percentile >= rg.range
GROUP BY os.outlet_id, os.customer_class_id, os.class_title, os.template_id;

alter materialized view analysis_d_outlet_percentile_grades owner to rosia;


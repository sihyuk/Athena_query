create materialized view analysis_a_outlet_class_sku_map as
SELECT ro_sku.retailoutlet_id   AS outlet_id,
       ascm.sku_id              AS sku_master_id,
       sku.name                 AS sku,
       ascm.id                  AS sku_class_id,
       ascm.sku_title,
       at.id                    AS template_id,
       at.template_title,
       ascm.customer_class_id,
       acc.customer_class_title AS class_title
FROM retailshop_skus ro_sku
         JOIN analysis_sku_class_map ascm ON ascm.sku_id = ro_sku.sku_id
         JOIN analysis_customer_class acc ON acc.id = ascm.customer_class_id
         JOIN analysis_template at ON at.id = acc.template_id
         JOIN skuinventory sku ON sku.id = ascm.sku_id;

alter materialized view analysis_a_outlet_class_sku_map owner to rosia;


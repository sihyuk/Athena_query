create function raster_contained(raster, raster) returns boolean
    immutable
    strict
    language sql
as
$$
select $1::geometry @ $2::geometry
$$;

alter function raster_contained(raster, raster) owner to rosia;


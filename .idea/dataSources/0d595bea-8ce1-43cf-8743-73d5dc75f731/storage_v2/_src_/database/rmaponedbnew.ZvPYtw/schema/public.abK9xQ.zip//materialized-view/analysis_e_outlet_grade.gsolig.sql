create materialized view analysis_e_outlet_grade as
SELECT opg.outlet_id,
       s.name         AS street,
       t.name         AS town,
       opg.template_id,
       max(opg.grade) AS score
FROM analysis_d_outlet_percentile_grades opg
         JOIN retailoutlet_street ros ON ros.retailoutlet_id = opg.outlet_id
         JOIN street s ON ros.street_id = s.id
         JOIN town t ON t.id = s.town_id
GROUP BY opg.outlet_id, opg.template_id, s.name, t.name;

alter materialized view analysis_e_outlet_grade owner to rosia;


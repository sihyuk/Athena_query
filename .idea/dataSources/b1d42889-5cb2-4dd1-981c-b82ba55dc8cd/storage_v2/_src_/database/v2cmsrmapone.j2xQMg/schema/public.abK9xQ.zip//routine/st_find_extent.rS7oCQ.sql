create function st_find_extent(text, text) returns box2d
    immutable
    strict
    language sql
as
$$
SELECT _postgis_deprecate('ST_Find_Extent', 'ST_FindExtent', '2.2.0');
    SELECT ST_FindExtent($1,$2);
$$;

alter function st_find_extent(text, text) owner to rosia;


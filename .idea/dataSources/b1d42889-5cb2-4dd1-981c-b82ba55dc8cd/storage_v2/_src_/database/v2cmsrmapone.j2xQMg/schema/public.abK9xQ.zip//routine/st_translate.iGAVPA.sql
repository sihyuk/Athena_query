create function st_translate(geometry, double precision, double precision, double precision) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_Affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)
$$;

comment on function st_translate(geometry, double precision, double precision, double precision) is 'args: g1, deltax, deltay, deltaz - Translates the geometry to a new location using the numeric parameters as offsets. Ie: ST_Translate(geom, X, Y) or ST_Translate(geom, X, Y,Z).';

alter function st_translate(geometry, double precision, double precision, double precision) owner to rosia;

